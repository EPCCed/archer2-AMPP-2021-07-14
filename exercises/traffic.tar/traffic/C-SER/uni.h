float uni(void);
void rinit(int seed);
